let allTotal = 0;

    function addToCart(button) {
        const movieDiv = button.parentElement; 
    const priceText = movieDiv.querySelector('.price').textContent; 
    const price = parseFloat(priceText.replace('$', '')); 

    allTotal += price; 

    console.log("Price::", price); 
    console.log("Total:", allTotal); 
    const totalAmountElement = document.getElementById('totalAmount'); // Pronađi element za ukupno
    totalAmountElement.textContent = `$${allTotal.toFixed(2)}`;
    button.disabled = true;
    button.innerText = "Added"; 
    
    }
    